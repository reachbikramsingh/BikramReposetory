/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.example.service;

import com.example.findlocation.FindLocation;

/**
 *
 * @author DSSPAR
 */
public class TouristService {

    FindLocation findLocation=new LocationService();
    public String[] getLocation(String place) throws Exception
    {
        return findLocation.getLatLongPositions(place);
    }

}
