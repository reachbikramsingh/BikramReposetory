package com.example.service;

import com.example.drone.Admin;
import com.example.findlocation.Report;

public class ReportService implements Report {
	Admin ad = new Admin();
        @Override
	public void sendReport(String loc, String image,String city, String zone) {
	    try {
	        ad.getReports(loc, image,city,zone);
	    } catch (Exception ex) {
	    	System.out.println(ex.getMessage());
	    }
	    }
}
