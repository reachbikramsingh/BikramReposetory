/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.example.drone;

public class Drone {
    String location,capture;
    String latlog[];
    public String appKeyForPlaceService = "AIzaSyC2fjTx97Ylcm3pm3NK4YQ2ME9nlhBKVaQ";
    public String appKeyForDistService = "AIzaSyB3xhWqSFqoijDObIqJ3qjhPn-lXx1Oua0";
        
    public String getCapture() {
        return capture;
    }

    public void setCapture(String capture) {
        this.capture = capture;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String[] getLatlog() {
        return latlog;
    }

    public void setLatlog(String[] latlog) {
        this.latlog = latlog;
    }

   
}
