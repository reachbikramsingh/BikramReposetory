package com.example.drone;

import com.example.admin.DisplayCrime;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class EmergencyCop extends Cop{
	public String policeStationName;
	   DisplayCrime dc;
        public EmergencyCop(String name){
		this.policeStationName = name;
	}
	public void takeAction(String loc, String img,String city,String zone){

            dc=new DisplayCrime();
            for (int i = 0; i < crimes.length; i++) {
                if(zone.equals("east")&&crimes[i].equals("robery"))
                {
                   crimename=crimes[i];
                }
                else if(zone.equals("north")&&crimes[i].equals("killer"))
                {
                   crimename=crimes[i];
                }
                else if(zone.equals("south")&&crimes[i].equals("bomb threat"))
                {
                   crimename=crimes[i];
                }
                
               else if(zone.equals("west")&&crimes[i].equals("teasing"))
                {
                   crimename=crimes[i];
                }
               else{
                   continue;
               }
            }
            dc.crimeDisplay(img, crimename, loc, zone);
            dc.setVisible(true);
            System.out.println("\n--------------------- Emergency Cop Action --------------------- \n");
		System.out.println("Emergency cop is " + policeStationName +" taking action on image " + img +  " in location --> " + loc  );
			
	}

	
	}

