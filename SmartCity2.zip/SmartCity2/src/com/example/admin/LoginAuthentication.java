/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.admin;

import com.example.drone.Cop;
import com.example.drone.Drone;
import com.example.drone.TouristGuide;
import java.io.Console;
import java.util.Scanner;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;

public class LoginAuthentication extends Drone {

    public void validate(String username, String password) throws Exception {
        if (username.equals("guide") && password.equals("guide")) {
        	TouristGuide tourist = new TouristGuide();
        	tourist.touristGuide();
        }
        else if(username.equals("cop") && password.equals("cop")){
        	System.out.println("\nSuccessfully login. Welcome to Cop...");
        Cop cop=new Cop();
        cop.crimeDetails();
        
        }
        else{
        	System.out.println("\nPlease provide correct username and password");
        }
        
    }

    public static void main(String[] args) throws Exception {
    	
        @SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
        String username, password;
        System.out.print("username:");
        username=scanner.next();
        System.out.print("password:");
        Console console = System.console(); 
        if( System.console() == null ) 
		{ // inside IDE like Eclipse or NetBeans
		  final JPasswordField pf = new JPasswordField();
		  password = JOptionPane.showConfirmDialog(null, pf, "Enter password",JOptionPane.OK_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE ) == JOptionPane.OK_OPTION ? new String( pf.getPassword() ) : "";
                
                }
        else{
        	char[] passwordChar = console.readPassword();
        	password = passwordChar.toString();
        }
        
        LoginAuthentication loginAuthentication = new LoginAuthentication();
        loginAuthentication.validate(username, password);

    }

}
