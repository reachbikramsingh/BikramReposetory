/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.places;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author akhil
 */
public class Distance {

    private String distance;
    private String duration;

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public static Distance jsonToPontoReferencia(JSONObject pontoReferencia) {
        try {
            Distance result = new Distance();
            JSONObject elements = (JSONObject) pontoReferencia.getJSONArray("elements").get(0);
            JSONObject location = (JSONObject) elements.get("distance");
            JSONObject duration = (JSONObject) elements.get("duration");
            result.setDistance(location.getString("text"));
            result.setDuration(duration.getString("text"));
            return result;
        } catch (JSONException ex) {
            Logger.getLogger(Places.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public String toString() {
        return "Distance --> " + distance + " takes --> " + duration + ".";
    }
}
