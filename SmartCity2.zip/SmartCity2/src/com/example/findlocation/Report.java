package com.example.findlocation;

public interface Report {

	public void sendReport(String loc, String image,String city,String zone);
}
